var deck = []; //contien les 52 carte generee par le constructeur
var cartesJoueur = [];
var cartesBanque = [];
var comptCarte = 0;
var cash = 100;
var suits = ['spades', 'diams', 'clubs', 'hearts']; // spade , clubs, diamonds, hearth
var valeur = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
var message = document.getElementById("message");
var message2 = document.getElementById("message2");
var affichage = document.getElementById("affichage");
var afficheBanque = document.getElementById("afficheBanque");
var afficheJoueur = document.getElementById("afficheJoueur");
var valMainJoueur = document.getElementById("jValue");
var valMainBanque = document.getElementById("bValue");
var finDePartie = false;
var argent = document.getElementById("dollars");
var valeurdelamise = document.getElementById("mise").value;

// $(document).ready(function() {
//     $("#btnReset").hide();
// });

function hide() {
    $("#btnReset").hide();
}

$("#btnDeal").click(function() {
    start();
});

function Start() {
    createDeck();
    shuffleDeck(deck);
    dealNew();
    $("#start").hide();
    $("#message").hide();
    $("#dollars").html(cash + " $");
    if (cash < 0) {
        finDePartie = true;
        $("#message2").html("FONDS INSUFISANT");
        //message2.innerHTML = "FONDS INSUFISANT";
        $("#btnDeal").hide();
        $("#actions").hide();
        var gameoversound = new Audio('sound/gameover.wav');
        gameoversound.play();
        $("#btnReset").show();
        console.log(cash);
        valeurdelamise = 0;
        argent.innerHTML = "Game Over !!!";
    }
}




function createDeck() {
    for (s in suits) {
        var suit = suits[s][0].toUpperCase(); // prend le premier caractere de suits et le met en majuscule
        var bgColor = (suit == "S" || suit == "C") ? "black" : "red"; //si Spade ou Club color black else color red
        for (v in valeur) {
            var carteValeur = (v > 9) ? 10 : parseInt(v) + 1; //si la carte est a l'index 9 ou plus sa valeur est de 10 / pour les autres c'est l'index+1
            var carte = { //construit les cartes
                suit: suit,
                image: suits[s],
                bgColor: bgColor,
                carteNum: valeur[v],
                cartevaleur: carteValeur
            }
            deck.push(carte); //envoi la carte dans le paquet
        }

    }
}

function shuffleDeck(array) { //brasse le paquet de carte avec la fonction Math.random
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}

function dealNew() { //reset les values des array et le innerHTML
    cartesJoueur = [];
    cartesBanque = [];
    $("#afficheBanque").html("");
    $("#afficheJoueur").html("");
    valeurdelamise = document.getElementById("mise").value; //recupere la valeur de la mise
    cash = cash - valeurdelamise; //soustrait la mise de l'argent du joueur
    $("#dollars").html(cash + " $");
    $("#actions").show();
    document.getElementById("mise").disabled = true; //desactive la possibilite de changer sa mise une fois que les jeux sont fait
    $("#message2").html("");
    $("#jValue").html("");
    $("#bValue").html("");
    $("#btnDeal").hide();
    var dealsound = new Audio('sound/coin2.wav');
    dealsound.play();
    deal()
}

function deal() {
    for (x = 0; x < 2; x++) { //donne 2 cartes a la banques et 2 cartes au joueur
        cartesBanque.push(deck[comptCarte]);
        afficheBanque.innerHTML += afficheLesCartes(comptCarte, x);
        if (x == 0) {
            afficheBanque.innerHTML += "<div id='cache' style='left:100px;'></div>";
        }
        comptCarte++;
        cartesJoueur.push(deck[comptCarte]);
        afficheJoueur.innerHTML += afficheLesCartes(comptCarte, x); //affiche le total du joueur au moment du deal
        comptCarte++;
    }
    jValue.innerHTML = checkValeur(cartesJoueur);
    if (jValue.innerHTML == "21") {
        holdPlay();
    }
    console.log(cartesBanque);
    console.log(cartesJoueur);
}

function afficheLesCartes(n, x) { //recoit le comtCarte et la variable x de la fonction deal()
    var horPos = (x > 0) ? x * 60 + 100 : 100; //position horizontale des cartes
    return '<div class = "carte ' + deck[n].image + '" style="left:' + horPos + 'px;"> <div class = "topCarte suit">' + deck[n].carteNum + '<br></div> <div class = "midCarte suit"> </div> <div class = "lowCarte suit">' + deck[n].carteNum + '<br></div> </div> ';
}

function action(a) {
    console.log(a);
    switch (a) {
        case 'hit':
            hitCard(); //ajoute une carte a la main du joueur
            break;
        case 'hold':
            holdPlay(); //calcul les mains
            break;
    }
}

function hitCard() {
    cartesJoueur.push(deck[comptCarte]);
    afficheJoueur.innerHTML += afficheLesCartes(comptCarte, (cartesJoueur.length - 1)); //positionne les cartes suivantes
    comptCarte++;
    var rValu = checkValeur(cartesJoueur);
    jValue.innerHTML = rValu;
    var cardsound = new Audio('sound/cardflip.wav');
    cardsound.play();
    if (rValu > 21) {
        message2.innerHTML = "  --- BUST !!! ---";
        holdPlay();
    }
}

function holdPlay() {
    finDePartie = true;
    document.getElementById('cache').style.display = 'none';
    document.getElementById('actions').style.display = 'none';
    $("#btnDeal").show();
    //document.getElementById('message2').style.display = 'block';
    $("#message2").show();
    document.getElementById("mise").disabled = false; //active la possibilite de changer sa mise 
    var blackjackpay = 1;
    var valeurDealer = checkValeur(cartesBanque);
    bValue.innerHTML = valeurDealer;
    while (valeurDealer < 17 || valeurDealer < valeurJoueur) {
        cartesBanque.push(deck[comptCarte]);
        afficheBanque.innerHTML += afficheLesCartes(comptCarte, (cartesBanque.length - 1)); //positionne les cartes suivantes
        comptCarte++;
        valeurDealer = checkValeur(cartesBanque);
        bValue.innerHTML = valeurDealer;
        console.log(valeurDealer);
    }
    //determine le gagnant
    var valeurJoueur = checkValeur(cartesJoueur);
    console.log(valeurJoueur);
    if (valeurJoueur == 21 && cartesJoueur == 2) { // SI LE JOUEUR FAIT BLACKJACK DU PREMIER COUP
        console.log(cartesJoueur);
        message2.innerHTML = " --- BLACKJACK ---";
        blackjackpay = 1.5;
    }
    var valeurmise = parseInt(document.getElementById("mise").value) * blackjackpay;
    if ((valeurJoueur < 22 && valeurJoueur > valeurDealer) || (valeurDealer > 21 && valeurJoueur < 22)) {
        message2.innerHTML += '<span style="color:#6cf542;">VOUS AVEZ GAGNER $' + valeurmise * 2 + '</span>';
        cash = cash + (valeurmise * 2);
        var winsound = new Audio('sound/notif.wav');
        winsound.play();
        argent.innerHTML = cash;
    } else if (valeurJoueur > 21 || valeurJoueur < valeurDealer) {
        message2.innerHTML += '<br><span style="color:red;">VOUS AVEZ PERDU VOTRE MISE DE $' + valeurmise + '</span>';
        var loosesound = new Audio('sound/loose.wav');
        loosesound.play();
    } else if (valeurJoueur == valeurDealer) {
        message2.innerHTML += '<span style="color:#3399ff;">PUSH !!! VOUS RECUPEREZ VOTRE MISE DE $' + valeurmise + '</span>';
        cash = cash + (valeurmise);
        var pushsound = new Audio('sound/coin.wav');
        pushsound.play();
    }
}

function checkValeur(arr) { // calcule la valeur de l'As, soit 1 ou 11
    var chkMain = 0;
    var asValeur = false; //verifie si un AS a deja ete calculer
    for (var i in arr) {
        if (arr[i].carteNum == 'A' && !asValeur) {
            asValeur = true;
            chkMain = chkMain + 10;
        }
        chkMain = chkMain + arr[i].cartevaleur; //dans createDeck() j'ajoute +1 a la valeur de l'index de la carte donc 10+1 
    }
    if (asValeur && chkMain > 21) { //si le total de la main va depasser 21 , l'As vaut 1
        chkMain = chkMain - 10;
    }
    return chkMain;
}

function Reset() {
    location.reload();
}